<?
//PERHATIKAN CARA ADMIN MENGISI DATA

$cookie = "xxxxx";
$user_agent = "xxxxx";
